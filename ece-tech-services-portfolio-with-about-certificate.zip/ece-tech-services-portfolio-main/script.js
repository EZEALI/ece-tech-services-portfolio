document.getElementById('year').textContent=new Date().getFullYear();document.querySelector('.menu')?.addEventListener('click',()=>document.querySelector('.links').classList.toggle('open'));document.querySelector('.js-contact')?.addEventListener('click',e=>{if(e.currentTarget.getAttribute('href')==='mailto:contact@ecetech.local'){e.preventDefault();alert('Replace the placeholder email with your official ECE TECH SERVICES contact.')}});
document.querySelectorAll('[data-about-tab]').forEach(button=>{
  button.addEventListener('click',()=>{
    const target=button.dataset.aboutTab;
    document.querySelectorAll('[data-about-tab]').forEach(btn=>{
      const active=btn===button;
      btn.classList.toggle('active',active);
      btn.setAttribute('aria-selected',active?'true':'false');
    });
    document.querySelectorAll('.about-panel').forEach(panel=>{
      const active=panel.id===target;
      panel.classList.toggle('active',active);
      panel.hidden=!active;
    });
  });
});

const certificateModal=document.createElement('div');
certificateModal.className='certificate-modal';
certificateModal.innerHTML='<div class="certificate-modal-box"><button class="certificate-modal-close" type="button" aria-label="Close certificate">×</button><iframe src="assets/ece-tech-services-certificate.pdf" title="Full ECE TECH SERVICES Certificate"></iframe></div>';
document.body.appendChild(certificateModal);

document.querySelector('.view-certificate')?.addEventListener('click',()=>{
  certificateModal.classList.add('open');
});

certificateModal.querySelector('.certificate-modal-close')?.addEventListener('click',()=>{
  certificateModal.classList.remove('open');
});

certificateModal.addEventListener('click',event=>{
  if(event.target===certificateModal) certificateModal.classList.remove('open');
});

document.addEventListener('keydown',event=>{
  if(event.key==='Escape') certificateModal.classList.remove('open');
});
